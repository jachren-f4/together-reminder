# Storage Layout

Placeholder.